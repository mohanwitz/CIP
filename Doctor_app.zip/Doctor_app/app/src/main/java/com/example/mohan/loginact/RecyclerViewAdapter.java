package com.example.mohan.loginact;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;


/**
 * Created by User on 1/1/2018.
 */

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>{

    private static final String TAG = "RecyclerViewAdapter";

    private ArrayList<String> patient_name = new ArrayList<>();
    private ArrayList<String> tokeno = new ArrayList<>();
    private ArrayList<String> time = new ArrayList<>();
    private Context mContext;
    private int flag;

    public RecyclerViewAdapter(Context context, ArrayList<String> patient_name, ArrayList<String> tokeno , ArrayList<String> time,int flag) {
        this.patient_name = patient_name;
        this.tokeno = tokeno;
        this.time = time;
        mContext = context;
        this.flag = flag;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.thread, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        holder.pid.setText("Patient_id : "+patient_name.get(position));
        holder.time.setText("Time : "+time.get(position));
        holder.tokeno.setText("Tokeno: : "+tokeno.get(position));

        /*holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "onClick: clicked on: " + category.get(position));

               // Toast.makeText(mContext, category.get(position), Toast.LENGTH_SHORT).show();
                if(flag == 0) {
                    Intent intent = new Intent(mContext, ViewThread.class);
                    intent.putExtra("image_url", mImages.get(position));
                    intent.putExtra("image_name", category.get(position));
                    intent.putExtra("thread_status",mstatus.get(position) );
                    mContext.startActivity(intent);
                }
                else {
                    Intent intent = new Intent(mContext, ViewThread_scheduled.class);
                    intent.putExtra("image_url", mImages.get(position));
                    intent.putExtra("image_name", category.get(position));
                    mContext.startActivity(intent);
                }

            }
        });*/
    }

    @Override
    public int getItemCount() {
        return patient_name.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView pid,time,tokeno;
        LinearLayout parentLayout;

        public ViewHolder(View itemView) {
            super(itemView);
            pid = itemView.findViewById(R.id.pid);
            time = itemView.findViewById(R.id.Time);
            tokeno = itemView.findViewById(R.id.Tokeno);
            parentLayout = itemView.findViewById(R.id.parent);
        }
    }
}














