package com.example.mohan.loginact;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import static com.example.mohan.loginact.image_upload.MY_PERMISSIONS_REQUEST_LOCATION;

public class Home extends AppCompatActivity {


    RecyclerView recyclerView;
    LinearLayout parentLinearLayout;
    FirebaseAuth mAuth;
    DatabaseReference threadRef,ref;
    String userid,docid,formattedDate;
    TextView textView;
    private Button start;
    Button sort;

    private ArrayList<String> patient_name = new ArrayList<>();
    private ArrayList<String> tokeno = new ArrayList<>();
    private ArrayList<String> time = new ArrayList<>();
    private Boolean exit = false;




    @Override
    public void onBackPressed() {

        moveTaskToBack(true);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home2);

        mAuth = FirebaseAuth.getInstance();

        threadRef = FirebaseDatabase.getInstance().getReference();
        ref = FirebaseDatabase.getInstance().getReference();

        FirebaseUser user = mAuth.getCurrentUser();
        userid = user.getUid();
        sort = (Button) findViewById(R.id.findsort);
        textView = (TextView)findViewById(R.id.textView6);
        recyclerView = (RecyclerView)findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        parentLinearLayout = (LinearLayout) findViewById(R.id.parent);
        start=(Button)findViewById(R.id.start);

        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yy");
        formattedDate = df.format(c);

        sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),shortest.class);
                startActivity(intent);
            }
        });
        threadRef.child("DoctorsAppointment").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                insert(dataSnapshot);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        ref.child("Doctors").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                finddocid(dataSnapshot);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Home.this,first.class);
               /* intent.putExtra("patient_name", patient_name);
                intent.putExtra("tokeno",tokeno);
                intent.putExtra("time",time);*/
                startActivity(intent);

            }
        });

    }

    public void finddocid(DataSnapshot dataSnapshot) {

        for(DataSnapshot ds : dataSnapshot.getChildren()) {

            doctor uInfo = new doctor();
            uInfo.setUserid(ds.getValue(doctor.class).getUserid());
            uInfo.setDocid(ds.getValue(doctor.class).getDocid());
            if(uInfo.getUserid().equals(userid)) {
                docid = uInfo.getDocid();
            }

        }
    }

    public void insert(DataSnapshot dataSnapshot) {
        patient_name.clear();
        time.clear();
        tokeno.clear();
        final String[] tt = new String[1];

        for (DataSnapshot ds : dataSnapshot.getChildren()) {

            if (ds.getKey().equals(formattedDate)) {
                for (DataSnapshot temp : ds.getChildren()) {
                    if (temp.getKey().equals(docid)) {
                        for (DataSnapshot temp1 : temp.getChildren()) {
                            final appointmentdetails info = new appointmentdetails();
                            info.setPid(temp1.getValue(appointmentdetails.class).getPid());
                            info.setTime(temp1.getValue(appointmentdetails.class).getTime());
                            info.setToken(temp1.getValue(appointmentdetails.class).getToken());
                            patient_name.add(info.getPid());
                            time.add(info.getTime());
                            tokeno.add(info.getToken());
                        }
                        initrecylerview();
                }
            }
            }

        }
    }

    public void initrecylerview()
    {
        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        RecyclerViewAdapter adaptar = new RecyclerViewAdapter(this,patient_name,tokeno,time,0);
        recyclerView.setAdapter(adaptar);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    protected void onPause() {
        super.onPause();
    }



    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {

        final MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.logout,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.menuLogout:
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this,MainActivity.class));
                break;
        }
        return true;

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode ==  MY_PERMISSIONS_REQUEST_LOCATION) {


            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this, "location permission granted", Toast.LENGTH_LONG).show();

            } else {

                Toast.makeText(this, "location permission denied", Toast.LENGTH_LONG).show();

            }

        }


    }


}



