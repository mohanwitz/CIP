package com.example.mohan.loginact;

public class livetokencount {
    String live;

    public String getLive() {
        return live;
    }

    public livetokencount(){

    }

    public void setLive(String live) {
        this.live = live;
    }

    public livetokencount(String live) {
        this.live = live;
    }
}
