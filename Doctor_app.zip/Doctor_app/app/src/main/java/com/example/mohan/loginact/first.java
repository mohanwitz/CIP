
package com.example.mohan.loginact;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.TimeZone;

public class first extends AppCompatActivity {
    private Button entry;
    private Button exit;
    private String current_time1,current_time2;
    String toast1="Entry time Noted!";
    int flag=0;
    private TextView patient_name1,tokeno1,time1;
    int i=-1,size;
    private ArrayList<String> patient_name = new ArrayList<>();
    private ArrayList<String> tokeno = new ArrayList<>();
    private ArrayList<String> time = new ArrayList<>();
    String userid,docid,formattedDate;
    FirebaseAuth mAuth;
    DatabaseReference threadRef,ref;
    int count = 0;
    String age,gender,chronic,charactersitics,docexp,pid;
    String result_time = null;
    int j=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        size=patient_name.size();
        entry = (Button) findViewById(R.id.entry);
        exit = (Button) findViewById(R.id.exit);
        patient_name1 = (TextView)findViewById(R.id.patient_name1);
        tokeno1 = (TextView)findViewById(R.id.tokeno1);
        time1 = (TextView)findViewById(R.id.time1);
        threadRef = FirebaseDatabase.getInstance().getReference();
        ref = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        userid = user.getUid();

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("MM-dd-yy");
        formattedDate = df.format(c);

        threadRef.child("DoctorsAppointment").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                insert(dataSnapshot);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        ref.child("Doctors").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                finddocid(dataSnapshot);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        entry.setEnabled(true);
        exit.setEnabled(false);
        entry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                current_time1=get_current_time();
                Toast.makeText(getApplicationContext(),toast1,Toast.LENGTH_SHORT).show();
                exit.setEnabled(true);
                entry.setEnabled(false);
            }
        });


        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                current_time2= get_current_time();
                try {
                    result_time=get_difference();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                i++;
                j++;
                threadRef.child("DoctorsAppointment").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        findcount(dataSnapshot);
                        insert1(dataSnapshot);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                threadRef.child("DoctorsAppointment").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        findflaskdata1(dataSnapshot);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                threadRef.child("Clients").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        findflaskdata2(dataSnapshot);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                threadRef.child("Doctors").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        finddocid(dataSnapshot);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                Toast.makeText(getApplicationContext(),result_time,Toast.LENGTH_SHORT).show();
                new FetchWeatherData().execute();
                entry.setEnabled(true);
                exit.setEnabled(false);

            }
        });




    }

    private void findflaskdata2(DataSnapshot dataSnapshot) {

        for(DataSnapshot ds : dataSnapshot.getChildren())
        {
            if(ds.getKey().equals(pid))
            {
                patientdetials detials = new patientdetials();
                detials.setAge(ds.getValue(patientdetials.class).getAge());
                detials.setGender(ds.getValue(patientdetials.class).getGender());

                age = detials.getAge();
                gender = detials.getGender();
            }
        }

    }

    private void findflaskdata1(DataSnapshot dataSnapshot) {

        for (DataSnapshot ds : dataSnapshot.getChildren()) {

            if (ds.getKey().equals(formattedDate)) {
                for (DataSnapshot temp : ds.getChildren()) {
                    if (temp.getKey().equals(docid)) {
                        for (DataSnapshot temp1 : temp.getChildren()) {
                            if(temp1.getKey().equals(Integer.toString(j))) {
                                final appointmentdetails info = new appointmentdetails();
                                info.setPid(temp1.getValue(appointmentdetails.class).getPid());
                                info.setTime(temp1.getValue(appointmentdetails.class).getTime());
                                info.setToken(temp1.getValue(appointmentdetails.class).getToken());
                                info.setChronic(temp1.getValue(appointmentdetails.class).getChronic());
                                info.setCharc(temp1.getValue(appointmentdetails.class).getCharc());
                                info.setId(temp1.getValue(appointmentdetails.class).getId());

                                pid = info.getId();
                                charactersitics = info.getCharc();
                                chronic = info.getChronic();
                            }

                        }

                    }
                }

            }
        }

    }


    private void findcount(DataSnapshot dataSnapshot) {
        count = 0;
        for (DataSnapshot ds : dataSnapshot.getChildren()) {

            if (ds.getKey().equals(formattedDate)) {
                for (DataSnapshot temp : ds.getChildren()) {
                    if (temp.getKey().equals(docid)) {
                        for (DataSnapshot temp1 : temp.getChildren()) {
                            count++;
                        }
                    }
                }
            }
        }
    }


    private String  get_current_time()
    {
        Date dateobj = new Date();
        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        String timeMedium = df.format(dateobj);
        return timeMedium;
    }
    public String get_difference() throws Exception {


        DateFormat format1 = new SimpleDateFormat("HH:mm:ss");
        DateFormat format2 = new SimpleDateFormat("HH:mm:ss");


        format2.setTimeZone(TimeZone.getTimeZone("UTC"));

        Date date1 = format1.parse(current_time1);
        Date date2 = format1.parse(current_time2);
        long difference = date2.getTime() - date1.getTime();

        Date result = new Date(difference);
        String result1=format2.format(result);

        return result1;
    }

    public void finddocid(DataSnapshot dataSnapshot) {

        for(DataSnapshot ds : dataSnapshot.getChildren()) {

            doctor uInfo = new doctor();
            uInfo.setUserid(ds.getValue(doctor.class).getUserid());
            uInfo.setDocid(ds.getValue(doctor.class).getDocid());
            uInfo.setExperience(ds.getValue(doctor.class).getExperience());
            if(uInfo.getUserid().equals(userid)) {
                docid = uInfo.getDocid();
                docexp = uInfo.getExperience();
            }

        }
    }

    public void insert(DataSnapshot dataSnapshot) {
        patient_name.clear();
        time.clear();
        tokeno.clear();
        final String[] tt = new String[1];
        for (DataSnapshot ds : dataSnapshot.getChildren()) {

            if (ds.getKey().equals(formattedDate)) {
                for (DataSnapshot temp : ds.getChildren()) {
                    if (temp.getKey().equals(docid)) {
                        for (DataSnapshot temp1 : temp.getChildren()) {
                            final appointmentdetails info = new appointmentdetails();
                            info.setPid(temp1.getValue(appointmentdetails.class).getPid());
                            info.setTime(temp1.getValue(appointmentdetails.class).getTime());
                            info.setToken(temp1.getValue(appointmentdetails.class).getToken());

                            time.add(info.getTime());
                            tokeno.add(info.getToken());
                            patient_name.add(info.getToken());
                        }

                }
            }

        }
    }
    }

    private void viewlist() {
        patient_name1.setText("Name : "+patient_name.get(0));
        time1.setText("Tokeno : "+tokeno.get(0));
        tokeno1.setText("Time : "+time.get(0));

    }
    public void insert1(DataSnapshot dataSnapshot) {
        patient_name.clear();
        time.clear();
        tokeno.clear();
        final String[] tt = new String[1];

        for (DataSnapshot ds : dataSnapshot.getChildren()) {

            if (ds.getKey().equals(formattedDate)) {
                for (DataSnapshot temp : ds.getChildren()) {
                    if (temp.getKey().equals(docid)) {
                        for (DataSnapshot temp1 : temp.getChildren()) {
                            final appointmentdetails info = new appointmentdetails();
                            info.setPid(temp1.getValue(appointmentdetails.class).getPid());
                            info.setTime(temp1.getValue(appointmentdetails.class).getTime());
                            info.setToken(temp1.getValue(appointmentdetails.class).getToken());
                            time.add(info.getTime());
                            tokeno.add(info.getToken());
                            patient_name.add(info.getPid());

                        }
                        viewlist1();
                    }

                }
            }
        }
    }

    private void viewlist1() {

        if(i>=count)
        {
            Toast.makeText(getApplicationContext(),"Appointments Over!",Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(first.this,Home.class);
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("tokencount");

            livetokencount live = new livetokencount("Finished");
            databaseReference.child(docid).setValue(live);
            startActivity(intent);
        }
        else {
            patient_name1.setText("Name : "+patient_name.get(i));
            time1.setText("Tokeno : "+tokeno.get(i));
            tokeno1.setText("Time : "+time.get(i));

            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("tokencount");

            livetokencount live = new livetokencount(tokeno.get(i));
            databaseReference.child(docid).setValue(live);

        }

    }

    private class FetchWeatherData extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            HttpURLConnection conn = null;
            try {
                URL url = new URL("http://192.168.137.12:5005/?age="+age+"&gen="+gender+"&chron="+chronic+"&char="+charactersitics+"&docexp="+docexp+"&time="+result_time);
                conn = (HttpURLConnection) url.openConnection();
                try {
                    InputStreamReader input = new InputStreamReader(conn.getInputStream());
                    int temp = conn.getResponseCode();
                    BufferedReader r = new BufferedReader(input);
                    final StringBuilder total = new StringBuilder();
                    for (String line; (line = r.readLine()) != null; ) {
                        total.append(line).append('\n');
                    }
                    final String temp2 = total.toString();
                    StringTokenizer st1 = new StringTokenizer(temp2,".");
                    final String temp1 = st1.nextToken();


                } finally {
                    conn.disconnect();
                }
            } catch (Exception e) {
                Log.d("Error2", String.valueOf(e));

            }
            return null;

        }
    }

}
