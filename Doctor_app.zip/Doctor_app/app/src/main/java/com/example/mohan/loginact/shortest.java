package com.example.mohan.loginact;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.StringTokenizer;

public class shortest extends AppCompatActivity {

    String pid,distance,time;
    double lat,lon;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shortest);
        text = (TextView) findViewById(R.id.sort);
        new finddata().execute();


    }


    private class finddata extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            HttpURLConnection conn = null;
            try {
                URL url = new URL("http://192.168.137.12:5010/result");
                conn = (HttpURLConnection) url.openConnection();
                try {
                    InputStreamReader input = new InputStreamReader(conn.getInputStream());
                    int temp = conn.getResponseCode();
                    BufferedReader r = new BufferedReader(input);
                    final StringBuilder total = new StringBuilder();
                    for (String line; (line = r.readLine()) != null; ) {
                        total.append(line).append('\n');
                    }
                    String temp2 = total.toString();
                    temp2 += " ";
                    StringTokenizer st1 = new StringTokenizer(temp2," ");
                    pid = st1.nextToken();
                    pid = pid.substring(1);
                    distance = st1.nextToken();
                    time = st1.nextToken();
                    lat = Double.parseDouble(st1.nextToken());
                    lon = Double.parseDouble(st1.nextToken());

                    DatabaseReference myRef = FirebaseDatabase.getInstance().getReference();

                    myRef.child("Clients").addListenerForSingleValueEvent(new ValueEventListener() {

                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot1) {

                            for (DataSnapshot temp : dataSnapshot1.getChildren()) {
                                //text.setText(pid);
                                if (temp.getKey().equals(pid)) {

                                    MemberProfile profile = new MemberProfile();
                                    profile.setFname(temp.getValue(MemberProfile.class).getFname());
                                    pid = profile.getFname();
                                    text.setText(Double.toString(lat));
                                    break;
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });


                    Intent intent = new Intent(getApplicationContext(),MapsActivity.class);
                    intent.putExtra("name",pid);
                    intent.putExtra("distance",distance);
                    intent.putExtra("time",time);
                    intent.putExtra("lat",Double.toString(lat));
                    intent.putExtra("lon",Double.toString(lon));
                    startActivity(intent);


                } finally {
                    conn.disconnect();
                }
            } catch (Exception e) {
                Log.d("Error3", String.valueOf(e));

            }
            return null;

        }
    }
}
