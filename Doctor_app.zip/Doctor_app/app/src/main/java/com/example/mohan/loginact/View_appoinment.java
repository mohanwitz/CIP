package com.example.mohan.loginact;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.akexorcist.googledirection.DirectionCallback;
import com.akexorcist.googledirection.GoogleDirection;
import com.akexorcist.googledirection.constant.RequestResult;
import com.akexorcist.googledirection.model.Direction;
import com.akexorcist.googledirection.model.Info;
import com.akexorcist.googledirection.model.Leg;
import com.akexorcist.googledirection.model.Route;
import com.google.android.gms.maps.model.LatLng;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.StringTokenizer;

public class View_appoinment extends AppCompatActivity {

    double latitude,longitude;
    TextView result,distanceandtime;
    String did,time,tokeno,date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_appoinment);


        did = getIntent().getStringExtra("did");
        date = getIntent().getStringExtra("date");
        time = getIntent().getStringExtra("time");
        tokeno = getIntent().getStringExtra("tokeno");

        result = (TextView)findViewById(R.id.result);
        distanceandtime = (TextView)findViewById(R.id.distanceandtime);
        distanceandtime.setText("hry");

        final String[] distance = new String[1];
        final String[] duration = new String[1];

        String serverKey = "AIzaSyDfBU93mmTnnu34vMDmcOQFkX8oJ7ifNRs";
        LatLng origin = new LatLng(13.012303, 80.240315);
        LatLng destination = new LatLng(13.009293, 80.213186);

        GPSTracker gps = new GPSTracker(View_appoinment.this);
        if(gps.canGetLocation())
        {
            latitude = gps.getLatitude();
            longitude = gps.getLongitude();
        }
        //result.setText("Latitude"+Double.toString(latitude)+"\nLongitude"+Double.toString(longitude));

        distanceandtime.setText("hey");
        GoogleDirection.withServerKey(serverKey)
                .from(origin)
                .to(destination)
                .execute(new DirectionCallback() {
                    @Override
                    public void onDirectionSuccess(Direction direction, String rawBody) {
                        // Do something here
                        String status = direction.getStatus();
                        result.setText(status);
                        if(status.equals(RequestResult.OK)) {
                            Route route = direction.getRouteList().get(0);
                            Leg leg = route.getLegList().get(0);
                            Info distanceInfo = leg.getDistance();
                            Info durationInfo = leg.getDuration();
                            distance[0] = distanceInfo.getText();
                            duration[0] = durationInfo.getText();

                            StringTokenizer st1 = new StringTokenizer(duration[0]," ");
                            int delaytime = Integer.parseInt(st1.nextToken());

                            StringTokenizer st2 = new StringTokenizer(time,".");
                            int h = Integer.parseInt(st2.nextToken());
                            int m = Integer.parseInt(st2.nextToken());

                            SimpleDateFormat sdf1 = new SimpleDateFormat("HH.mm");

                            Calendar calendar = new GregorianCalendar(2013,1,28,h,m,00);

                            calendar.add(Calendar.MINUTE,-delaytime);

                            time =sdf1.format(calendar.getTime()).toString();

                            //String did,time,tokeno,date;

                            result.setText("Distance = "+distance[0]+"\nDuration = "+duration[0]+"\nTime to leave = "+time+"\nTokeno = "+tokeno+"\nDate = "+date);

                            try {
                                Thread.sleep(5000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            return;
                        } else if(status.equals(RequestResult.NOT_FOUND)) {
                            // Do something
                        }
                    }
                    @Override
                    public void onDirectionFailure(Throwable t) {
                        // Do something here
                    }
                });
        //distanceandtime.setText("Distance = "+distance[0]+"\nDuration = "+duration[0]);*/



    }
}
