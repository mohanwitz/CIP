package com.example.mohan.loginact;

public class checking_admin {

    public  String admin_user;

    public String getAdmin_user() {
        return admin_user;
    }

    public void setAdmin_user(String admin_user) {
        this.admin_user = admin_user;
    }

    public checking_admin(String admin_user)
    {
        this.admin_user = admin_user;
    }

    public checking_admin()
    {

    }
}
