package com.example.mohan.loginact;

public class Constants {

    public static final String CHANNEL_ID = "mychannelid";
    public static final String CHANNEL_NAME = "mychannelname";
    public static final String CHANNEL_DESCRIPTION = "my description";

}
