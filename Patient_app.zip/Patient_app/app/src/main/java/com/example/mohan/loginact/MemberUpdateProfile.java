package com.example.mohan.loginact;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Member;

public class MemberUpdateProfile extends AppCompatActivity {


    EditText fname,Location,Phoneno,lname,age,gender;
    Button update;

    FirebaseAuth mAuth;
    DatabaseReference databaseReference;

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;
    private  String userID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_update_profile);

        update  = (Button)findViewById(R.id.update);
        fname  = (EditText)findViewById(R.id.name);
        gender  = (EditText)findViewById(R.id.gender);
        lname  = (EditText)findViewById(R.id.lname);
        Location  = (EditText)findViewById(R.id.Location);
        age = (EditText)findViewById(R.id.age5);
        Phoneno  = (EditText)findViewById(R.id.Phoneno);


        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        FirebaseUser user = mAuth.getCurrentUser();
        userID = user.getUid();

        mAuth = FirebaseAuth.getInstance();

        update();

    }

    private void update() {

        myRef.child("Clients").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                showData(dataSnapshot);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void showData(DataSnapshot dataSnapshot) {

        FirebaseUser user = mAuth.getCurrentUser();

        String id = user.getUid();
        for(DataSnapshot ds : dataSnapshot.getChildren()){

            if(ds.getValue(MemberProfile.class).userid.equals(id)) {

                MemberProfile uInfo = new  MemberProfile ();
                uInfo.setFname(ds.getValue( MemberProfile.class).getFname());
                uInfo.setLname(ds.getValue( MemberProfile.class).getLname());
                uInfo.setGender(ds.getValue( MemberProfile.class).getGender());
                uInfo.setAge(ds.getValue( MemberProfile.class).getAge());
                uInfo.setLocation(ds.getValue( MemberProfile.class).getLocation());
                uInfo.setPhoneno(ds.getValue( MemberProfile.class).getPhoneno());


                fname.setText(uInfo.getFname());
                lname.setText(uInfo.getLname());
                gender.setText(uInfo.getGender());
                age.setText(uInfo.getAge());
                Location.setText(uInfo.getLocation());
                Phoneno.setText(uInfo.getPhoneno());


            }
            update.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    updatepof();
                }
            });

        }

    }

    private void updatepof() {

        String fname1 = fname.getText().toString();
        String lname1 = lname.getText().toString();
        String location = Location.getText().toString();
        String age1 = age.getText().toString();
        String gender1 = gender.getText().toString();
        String phoneno = Phoneno.getText().toString();


        if(fname1.isEmpty())
        {
            fname.setError("Please enter the name");
            fname.requestFocus();
            return;
        }

        if(lname1.isEmpty())
        {
            lname.setError("Please enter the name");
            lname.requestFocus();
            return;
        }

        if(location.isEmpty())
        {
            Location.setError("Please enter the Location");
            Location.requestFocus();
            return;
        }


        if(age1.isEmpty())
        {
            age.setError("Please enter your age");
            age.requestFocus();
            return;
        }

        if(phoneno.isEmpty())
        {
            Phoneno.setError("Please enter your Phone number");
            Phoneno.requestFocus();
            return;
        }

        if(gender1.isEmpty())
        {
            gender.setError("Please enter your Phone number");
            gender.requestFocus();
            return;
        }

        FirebaseUser user = mAuth.getCurrentUser();

        String id = user.getUid();

        databaseReference = FirebaseDatabase.getInstance().getReference("Clients").child(id);

        MemberProfile prof = new MemberProfile(fname1, lname1, age1, gender1,location,phoneno,id);

        databaseReference.setValue(prof).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(getApplicationContext(),"Profile updated Successfully",Toast.LENGTH_SHORT).show();}
        });


    }
}
